import './App.css'
import RegistrationForm from './components/UserForm'

function App() {

  return (
    <>
      <RegistrationForm/>
    </>
  )
}

export default App
